
export interface NewsArticle {
  title: string;
  summary: string;
  source: string;
  link: string;
}
